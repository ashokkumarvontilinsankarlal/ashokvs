package project;

class ExamRegistrar {

	 private ExamRegistrar(){   }

	 public static ExamRegistrar getExamRegistrar(){

	  return new ExamRegistrar();

	 } 

	public Exam registeringStudentForExamination (Student student){

		//System.out.println(" Register exam 1");

	 Paper paper=new Paper();

	 Exam exam=new Exam(paper);

	 return exam;

	 }

}