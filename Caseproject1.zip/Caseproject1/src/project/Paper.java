package project;


class Paper {

	public String submit(){

		System.out.println(" Paper uplodaed ");

		  Evaluator evaluator=Evaluator.getEvaluator();

		  return evaluator.evaluate(this);

		}

}