package project;

import java.util.Scanner;



public class Administration {



	public static void main(String[] args) {

			

		@SuppressWarnings("resource")
		Scanner sc=new Scanner (System.in);

		 System.out.println("Enter Student Details:");
		 
		 System.out.println("Enter Student name:");

		 String name = sc.next();		 
		 
		 System.out.println("Enter Age:");
		 
		 int age = sc.nextInt();		
		 
		 System.out.println("Enter Student sex:");
		 
		 String sex = sc.next();		 

		 System.out.println("Enter Student DOB:");
		 
		 String dob = sc.next();		 
		 
		 System.out.println("Enter Student address:");

		 String address = sc.next();		 

		 System.out.println("Enter Student primary mail:");
		 
		 String  pri_email = sc.next();		 
		 
		 System.out.println("Enter Student Secondary email:");

		 
		 String sec_email = sc.next();	
		 
		 System.out.println("Enter Student phone number:");

		 long ph = sc.nextLong();	
		 
		 System.out.println("Enter Student highest education:");

		 String high_edu = sc.next();	
		 
		 System.out.println("Enter Student nationality:");

		 String nationality = sc.next(); 

		 sc.close();

		 Student s = new Student(name, age, sex, dob, address, pri_email, sec_email, ph, high_edu, nationality);

		 s.setName(name);

		 s.setAge(age);

		 s.setSex(sex);

		s.setDob(dob);

		 s.setAddress(address);

		 s.setPri_email(pri_email);

		 s.setSec_email(sec_email);

		 s.setPh(ph);

		

		 s.setHigh_edu(high_edu);

		 s.setNationality(nationality);

		 

		s.registerStudent();

		s.registerForExam();

		s.appearForExam();

	}



}