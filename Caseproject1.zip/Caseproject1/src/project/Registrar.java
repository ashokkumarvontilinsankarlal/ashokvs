package project;

import java.util.Random;



class Registrar {

	 private Registrar(){

		   

	 }

	public static Registrar getRegistrar(){

	  return new Registrar();

	}



	int registerStudent(Student student){

	   Validator validator=Validator.getValidator();

	 if(validator. validateStudentDetails (student))

	 {

	     //generate admission id and return it to the student

		 Random rand = new Random();

		 int ad_id = rand.nextInt(100000);

		 //String id = String.valueOf(ad_id);

		 System.out.println("  Admission Id generated:   ");

		 //System.out.println("Admission Id  is : "+ad_id);

	      return  ad_id;

	 }
	return 0;
	}
}
