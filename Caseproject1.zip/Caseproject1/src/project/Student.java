package project;

class Student {

    private static String Name; 

	private static String Marital_Status;

	private static int Age;

	private static String Sex;

	private static String dob; 

	private static String Address;

	private static String Pri_email;

	private static String Sec_email; 

	private static long Ph;


	private static String High_edu;

	private static String Nationality;

	private static int admissionId;

	private static String result;

	Exam exam; 

	  Student (String Name,int Age,String Sex,String dob,String Address,

			 String Pri_email,String Sec_email,long Ph,String High_edu,

			 String Nationality) 

	 {

		 

	  //assign student details to the member variables.

		 Student.setName(Name);

		 Student.setAge(Age);

		 Student.setSex(Sex);

		 Student.setDob(dob);

		 Student.setAddress(Address);

		 Student.setPri_email(Pri_email);

		 Student.setSec_email(Sec_email);

		 Student.setPh(Ph);

		 Student.setHigh_edu(High_edu);

		 Student.setNationality(Nationality);

		 

		  

	 }

	/* public String getName() {

		return Name;

	}*/

	 static void setName(String Name) {

		Student.Name = Name;

	}

	/*public String getMarital_Status() {

		return Marital_Status;

	}*/

	 static void setMarital_Status(String Marital_Status) {

		Student.Marital_Status = Marital_Status;

	}

	/*public int getAge() {

		return Age;

	}*/

	 static void setAge(int Age) {

		Student.Age = Age;

	}

	/*public String getSex() {

		return Sex;

	}*/

	 static void setSex(String Sex) {

		Student.Sex = Sex;

	}

	/*public String getDob() {

		return dob;

	}*/

	 static void setDob(String dob) {

		Student.dob = dob;

	}

	/*public String getAddress() {

		return Address;

	}*/

	 static void setAddress(String Address) {

		Student.Address = Address;

	}

	/*public String getPri_email() {

		return Pri_email;

	}*/

	 static void setPri_email(String Pri_email) {

		Student.Pri_email = Pri_email;

	}

	/*public String getSec_email() {

		return Sec_email;

	}*/

	 static void setSec_email(String Sec_email) {

		Student.Sec_email = Sec_email;

	}

	/*public long getPh() {

		return Ph;

	}*/

	 static void setPh(long Ph) {

		Student.Ph = Ph;

	}

	/*public String getSub() {

		return sub;

	}*/

	 

	/*public String getHigh_edu() {

		return high_edu;

	}*/

	 static void setHigh_edu(String High_edu) {

		Student.High_edu = High_edu;

	}

	/*public String getNationality() {

		return Nationality;

	}*/

	 static void setNationality(String Nationality) {

		Student.Nationality = Nationality;

	}

	 

	void registerStudent() {

	    Registrar registrar = Registrar.getRegistrar();

	 admissionId = registrar. registerStudent(this);

	 System.out.println("Admission Id = "+admissionId);

	   }

	void registerForExam(){

		System.out.println("Registering Exam Started");

	  ExamRegistrar  examRegistrar = ExamRegistrar.getExamRegistrar();

	 exam = examRegistrar.registeringStudentForExamination(this);

	 System.out.println(" Exam finished ");

	 }

	 void appearForExam(){

	 Paper paper = exam.getPaper();

	 result=paper.submit();

	 System.out.println(result);

	 }





}