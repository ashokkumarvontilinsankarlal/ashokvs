package project;

class Exam {

	 Paper paper;

	 Exam(Paper paper){

		 System.out.println(" Exam started ");

	 this.paper=paper;

	 } 

	 public  Paper getPaper(){

	  return paper;

	 }

}